# TECH OPTION V3

Upload all files/folders to the root of your GitHub Pages repository.

Main pages:
- index.html
- legal.html
- status.html
- assets/
